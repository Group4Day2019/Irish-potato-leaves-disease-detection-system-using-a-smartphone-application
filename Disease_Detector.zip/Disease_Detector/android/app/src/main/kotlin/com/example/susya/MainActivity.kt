package com.example.susya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
